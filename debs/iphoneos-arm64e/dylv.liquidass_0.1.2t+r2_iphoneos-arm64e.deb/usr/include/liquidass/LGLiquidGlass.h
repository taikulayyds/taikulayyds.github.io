#pragma once

#import <UIKit/UIKit.h>
#import <dlfcn.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const LGLiquidGlassErrorDomain;

typedef NS_ENUM(NSInteger, LGLiquidGlassError) {
    LGLiquidGlassErrorUnavailable = 1,
    LGLiquidGlassErrorInvalidIdentifier,
    LGLiquidGlassErrorInvalidParameter,
};

// do not reference as a class literal, use LGLiquidGlassMake/LGLiquidGlassViewCreate
@interface LGLiquidGlassView : UIView

+ (nullable instancetype)glassWithFrame:(CGRect)frame
                             identifier:(NSString *)identifier
                             parameters:(nullable NSDictionary<NSString *, id> *)parameters
                                  error:(NSError * _Nullable * _Nullable)error;

@property (nonatomic, copy, readonly) NSDictionary<NSString *, id> *lgParameters;
@property (nonatomic, copy, readonly) NSString *lgIdentifier;

@property (nonatomic, assign) CGFloat lgCornerRadius;
@property (nonatomic, assign, getter=isLGSpecularEnabled) BOOL lgSpecularEnabled;
@property (nonatomic, assign) CGFloat lgSpecularOpacity;
@property (nonatomic, assign) CGFloat lgBackdropZoom;

- (void)lgRefresh;

@end

typedef UIView * _Nullable (*LGLiquidGlassViewCreateFn)(CGRect frame,
                                                        NSString *identifier,
                                                        NSDictionary<NSString *, id> * _Nullable parameters,
                                                        NSError * _Nullable * _Nullable error);

UIView * _Nullable LGLiquidGlassViewCreate(CGRect frame,
                                           NSString *identifier,
                                           NSDictionary<NSString *, id> * _Nullable parameters,
                                           NSError * _Nullable * _Nullable error);

// resolves the entry point lazily via dlsym, returns nil if liquidass not loaded
static inline UIView * _Nullable LGLiquidGlassMake(CGRect frame,
                                                   NSString *identifier,
                                                   NSDictionary<NSString *, id> * _Nullable parameters,
                                                   NSError * _Nullable * _Nullable error) {
    static LGLiquidGlassViewCreateFn entry;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        entry = (LGLiquidGlassViewCreateFn)dlsym(RTLD_DEFAULT, "LGLiquidGlassViewCreate");
    });
    if (!entry) {
        if (error) *error = [NSError errorWithDomain:@"dylv.liquidass.liquid-glass"
                                                code:1
                                            userInfo:@{NSLocalizedDescriptionKey:
                                                @"liquidass is not loaded in this process"}];
        return nil;
    }
    return entry(frame, identifier, parameters, error);
}

NS_ASSUME_NONNULL_END
