# Third-party notices

## SingleVPN

Original project: https://github.com/owngoal-dev/SingleVPN
Reference fork: https://github.com/hxhlb/SingleVPN
Reference commit: 37ab60fd4a6b8649cadf1d73b1298cd312d71a6c

The status-update hooks and delta-merge approach are derived through the user-owned
Lunora project from SingleVPN. SIM-presence adaptation is from Lunora. DuoFlow
geometry and animation coordination are maintained independently. Distribute this
notice with the binary.

MIT License

Copyright (c) 2024-2025 OwnGoal Studio

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


## Harbor layout reference

Original project: https://github.com/eswick/harbor
Reference file: https://github.com/eswick/harbor/blob/master/Tweak.xm

The landscape fixed-X, sequential-Y arrangement and restoration of native icon
geometry were studied as a reference. DuoFlow's Dock layout, bounded scrolling,
state coordination and Control Center modules are independently implemented;
Harbor source code is not incorporated or redistributed.

## TrollPadEx capability reference

User-owned reference: https://github.com/hxhlb/TrollPadEx
Branch: TrollPadEx
Initial reference: 930dc5fd89f4e2e9f1b51595afcfdba544da0cf8 (2.0.1)
Current reference: b24575a4090394be5925f254628e164d6980a9f9 (2.0.3)
Reference files: TweakSB.x, TPPrefsObserver.h/m, TrollPadPrefs/Resources/Root.plist.
Upstream project: https://github.com/khanhduytran0/TrollPad

The SpringBoard selector names, native capability choices and grid tuning values
were studied as references and checked against native iOS 17 method signatures.
No TrollPadEx or TrollPad source is incorporated or redistributed. DuoFlow's
preference domain, dependency policy, typed hooks and reversible Dock option
handling are implemented independently. No global device idiom, Stage Manager,
keyboard, Medusa, persistent Apple preference or TrollPadEx dylib dependency is
imported. The inspected reference does not contain a license grant; this notice
records technical references and does not assert permission to copy its source.
Alpha31 independently applies its separate startup switcher choice, iOS26 raw
style entry, zero label spacing and missing-scene-setting Dock creation guard.
When TrollPadEx is loaded and enabled, DuoFlow delegates overlapping native
capabilities and switcher policy instead of installing a second active policy.

## Apple reference analysis

Original Apple binaries were inspected locally for numerical behavior. No Apple
binary, extracted texture, SF Symbols asset or original controller is redistributed
in this package. SF Symbols are resolved through the installed system API.

## Lunora preference controls

User-owned project: https://github.com/hxhlb/iPhoneDuoIcon
Reference files: Prefs/IDISliderCell.h/m and IDISliderInput.h.
The two Orbit position controls adapt Lunora's native slider, two-row numeric
editor, locale-aware input validation and single preference-writer behavior.
Class and localization names are scoped to DuoFlow; no Lunora binary is required.

## DuoLikeAnimation

Reference fork: https://github.com/hxhlb/DuoLikeAnimation
Upstream: https://github.com/elijah-semyonov/DuoLikeAnimation
Reference commit: 0aa525639a494be8abdf4c4e1e25dcb52d372d94

Historical alpha28/alpha29 used this reference's eye/glass projection. That
renderer is archived and is not compiled into alpha30. The current fold effect
independently reconstructs Apple's numerically verified mesh/radius/opacity
controls. The iOS 15 Metal rasterizer and Gaussian approximation are ours.
Motion uses independently maintained calibration/lifecycle policy; its bounded
gyro prediction was inspired by this reference. Attribution is retained.

MIT License

Copyright (c) 2026 Elijah Semyonov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
