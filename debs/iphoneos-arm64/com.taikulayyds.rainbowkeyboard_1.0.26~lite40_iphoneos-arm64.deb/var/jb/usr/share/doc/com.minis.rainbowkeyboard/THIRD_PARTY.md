# Historical Attribution

Earlier experimental releases contained a backboard renderer adapted
from the user-provided SBLiquidGlass source tree
`ceshi-main-透明玻璃代码`, whose README describes its origins in the
GPL-licensed LiquidAss architecture. Upstream package author: MoWang. The
supplied source carries the GNU GPL version 3 license, reproduced in
`COPYING.GPL-3.0`.

Since lite30, that renderer, the local Metal and mesh renderers, their
protocols, diagnostics, settings and dedicated tests have been removed.
They are not built, shipped or loaded. The ordinary adjustable UIKit blur
material remains. The following historical provenance and license are
retained to avoid removing notices associated with prior distributions.

Adapted components:

- `SBLiquidGlassBackboardd/LGSymbolResolver.h` and `.mm`: QuartzCore symbol
  resolution and arm64e pointer helpers.
- `SBLiquidGlassBackboardd/Tweak.mm`: the iOS 17.0 render calling convention,
  genuine Gaussian descriptor registration and scoped renderer interception.
- Optical convex-profile equations informed the keyboard-specific shader.

Modifications on 2026-09-24: independent keyboard filter namespace, bounded
initialization, validated geometry snapshots, shared keyboard capture,
keyboard-only Metal shader, zero-strength and renderer-unavailable fallback.
lite25 removes the unused edgeInfo scan prerequisite, compiles pipelines
asynchronously per source device, permits Unknown texture usage, defers
transient frames with a bounded retry budget, and reports staged diagnostics.
Clock, lock screen, desktop, notification and motion features are not included.
No upstream prebuilt binary is bundled.

The adapted reference component and corresponding modifications are provided
under GPL-3.0. The matching source for prior distributions must be retained
alongside those historical binaries. The lite30 source does not include the
removed components. Retain this notice and the license.
